Precompiled Libraries
=====================

In general, precompiled Mesa libraries are not available.

Some Linux distributions closely follow the latest Mesa releases. On
others one has to use unofficial channels.

There are some general directions:

-  Debian/Ubuntu based distributions - PPA: xorg-edgers, oibaf and padoka
-  Fedora - Copr: erp and che
-  OpenSuse/SLES - OBS: X11:XOrg and pontostroy:X11
-  Gentoo/Arch Linux - officially provided/supported
